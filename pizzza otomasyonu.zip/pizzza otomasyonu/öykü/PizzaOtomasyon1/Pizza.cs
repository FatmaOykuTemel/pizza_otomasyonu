﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOtomasyon1
{
    class Pizza:Tutar
    {
   
        public Ebat ebat { get; set; }
        public Kenar  kenarTipi { get; set; }
        public İcecek İcecek { get; set; }
      
        public override decimal toplamtutarfonksiyonu()
        {
            decimal pizzatutari = 0;
            pizzatutari = PizzaFiyat + ebat.EbatFiyat + kenarTipi.KenarFiyat + İcecek.İcecekFiyat;
            return pizzatutari;
        }

       public string PizzaAd { get; set; }
        public int PizzaFiyat { get; set; }

    }
}

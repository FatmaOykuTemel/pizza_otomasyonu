﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOtomasyon1
{
    class Vegan:Pizza,Icındekiler
    {
        public  string icindekiler()
        {
            List<string> malzeme = new List<string>();
            malzeme.Add("mısır");
            malzeme.Add("zeytin");
            malzeme.Add("biber");
            malzeme.Add("vegan sucuk");
            malzeme.Add("vegan pizza peyniri");
            return PizzaAd;
        }
        public override string ToString()
        {
            return string.Format("{0}--{1}", PizzaAd, PizzaFiyat);
        }
    }
}

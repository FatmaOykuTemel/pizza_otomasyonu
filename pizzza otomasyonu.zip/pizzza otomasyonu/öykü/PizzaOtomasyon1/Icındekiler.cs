﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOtomasyon1
{
    interface Icındekiler
    {
        string icindekiler();
     //   string Ad { get; set; }
        string ToString();


    }
}

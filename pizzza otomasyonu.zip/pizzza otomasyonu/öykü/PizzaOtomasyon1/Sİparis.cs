﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOtomasyon1
{
    class Sİparis:Tutar
    {
       
        public  Pizza pizza { get; set; }
        public int Adet { get; set; }

        public override decimal toplamtutarfonksiyonu()
        {

            decimal toplamtutar = 0;
            toplamtutar = pizza.toplamtutarfonksiyonu() * Adet;
            return toplamtutar;
        }

        public override string ToString()
        {

            return pizza.ToString();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOtomasyon1
{
    class Karısık:Pizza
    {
        public override string icindekiler()
        {
            List<string> malzeme = new List<string>();
            malzeme.Add("kaşar");
            malzeme.Add("sucuk");
            malzeme.Add("zeytin");
            malzeme.Add("mısır");
            malzeme.Add("mantar");
            malzeme.Add("salam");
            malzeme.Add("sosis");
            return PizzaAd;
        }
        public override string ToString()
        {
            return string.Format("{0}--{1}", PizzaAd, PizzaFiyat);
        }
    }
}

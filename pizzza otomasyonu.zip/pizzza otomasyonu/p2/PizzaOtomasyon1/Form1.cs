﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PizzaOtomasyon1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lbl_pizza.Text = "PİZZA";
            lbl_pizzaad.Text = "PİZZA";
            lbl_ebat.Text = "EBAT";
            lbl_kenar.Text = "KENAR";
            lbl_icecek.Text = "İCECEK";
            lbl_adet.Text = "ADET";
            lbl_fiyat.Text = "FİYAT";
            lbl_isim.Text = "İSİM";
            lbl_adres.Text = "ADRES";
            lbl_telefon.Text = "TELEFON";
            lbl_ödeme.Text = "ÖDEME YÖNTEMİ";
            btn_hesapla.Text = "HESAPLA";
            btn_sepet.Text = "SEPETE EKLE";
            btn_onay.Text = "SİPARİS ONAY";

            Klasik klasik = new Klasik { PizzaAd = "KLASİK", PizzaFiyat = 20 };
            Karısık karışık = new Karısık { PizzaAd = "KARIŞIK", PizzaFiyat = 25 };
            Napoliten napoliten = new Napoliten { PizzaAd = "NAPOLİTEN", PizzaFiyat = 30 };
            Vegan vegan = new Vegan { PizzaAd = "VEGAN", PizzaFiyat = 30 };
            Margerita margerita = new Margerita { PizzaAd = "MARGERİTA", PizzaFiyat = 30 };

           // listBox1.Items.Add(karışık.icindekiler);

            string[] dizi = new string[7];
            for (int i=0;i<7;i++)
            {
                i = listBox1.Items.Add(karışık.icindekiler());
            }
          

            cmb_pizza.Items.Add(klasik);
            cmb_pizza.Items.Add(margerita);
            cmb_pizza.Items.Add(karışık);
            cmb_pizza.Items.Add(napoliten);
            cmb_pizza.Items.Add(vegan);

            Ebat Kucuk = new Ebat { EbatAd = "KÜÇÜK", EbatFiyat = 1 };
            Ebat Orta = new Ebat { EbatAd = "ORTA", EbatFiyat = 2 };
            Ebat Buyuk = new Ebat { EbatAd = "BÜYÜK", EbatFiyat = 3 };

            cmb_ebat.Items.Add(Kucuk);
            cmb_ebat.Items.Add(Orta);
            cmb_ebat.Items.Add(Buyuk);

            Kenar kalın = new Kenar { KenarAd = "KALIN", KenarFiyat = 1 };
            Kenar ince = new Kenar { KenarAd = "İNCE", KenarFiyat = 2 };
            Kenar kaşar = new Kenar { KenarAd = "KAŞAR DOLGULU", KenarFiyat = 3 };
            Kenar susamlı = new Kenar { KenarAd = "SUSAMLI", KenarFiyat = 2 };
            Kenar sucuk = new Kenar { KenarAd = "SUCUKLU", KenarFiyat = 1 };

            cmb_kenar.Items.Add(kalın);
            cmb_kenar.Items.Add(ince);
            cmb_kenar.Items.Add(kaşar);
            cmb_kenar.Items.Add(susamlı);
            cmb_kenar.Items.Add(sucuk);

            İcecek bos = new İcecek { İcecekAd = "NO" , İcecekFiyat = 0 };
            İcecek kola = new İcecek { İcecekAd = "KOLA", İcecekFiyat = 5 };
            İcecek gazoz = new İcecek { İcecekAd = "GAZOZ", İcecekFiyat = 5 };
            İcecek icetea = new İcecek { İcecekAd = "İCETEA", İcecekFiyat = 5 };
            İcecek ayran = new İcecek { İcecekAd = "AYRAN", İcecekFiyat = 5 };
            İcecek fanta = new İcecek { İcecekAd = "FANTA", İcecekFiyat = 5 };

        
            cmb_icecek.Items.Add(bos);

            cmb_icecek.Items.Add(kola);
            cmb_icecek.Items.Add(gazoz);
            cmb_icecek.Items.Add(icetea);
            cmb_icecek.Items.Add(ayran);
            cmb_icecek.Items.Add(fanta);
 


            cmb_ödeme.Items.Add("kredi kartı");
            cmb_ödeme.Items.Add("nakit");
        }
         Pizza p;
        Sİparis siparis;
        private void btn_hesapla_Click(object sender, EventArgs e)
        {
            p = (Pizza)cmb_pizza.SelectedItem;
            p.ebat= (Ebat)cmb_ebat.SelectedItem;
            p.kenarTipi = (Kenar)cmb_kenar.SelectedItem;
            p.İcecek= (İcecek)cmb_icecek.SelectedItem;
      
            siparis = new Sİparis
            {
                pizza = p,
                Adet = (int)numericUpDown1.Value
            };

            decimal tutar = (decimal)siparis.toplamtutarfonksiyonu();  
    
             txt_fiyat.Text = tutar.ToString();
        }

        private void btn_sepet_Click(object sender, EventArgs e)
        {
            lst_görünüm.Items.Add(siparis);
            lst_görünüm.Items.Add(siparis.Adet);
            lst_görünüm.Items.Add(p.İcecek);
            lst_görünüm.Items.Add(p.kenarTipi);
            lst_görünüm.Items.Add(p.ebat);
            listBox1.Items.Add(txt_ad.Text);
            listBox1.Items.Add(txt_adres.Text);
            listBox1.Items.Add(txt_telefon.Text);

        }

        private void btn_onay_Click(object sender, EventArgs e)
        {
          
            MessageBox.Show(p.PizzaAd);
            MessageBox.Show(txt_fiyat.Text);         
            MessageBox.Show(txt_telefon.Text);
            MessageBox.Show(txt_adres.Text);

         //   Pizza pizza2 = new Pizza();



        }

        private void txt_adres_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
                && !char.IsSeparator(e.KeyChar);
        }

        private void txt_telefon_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}

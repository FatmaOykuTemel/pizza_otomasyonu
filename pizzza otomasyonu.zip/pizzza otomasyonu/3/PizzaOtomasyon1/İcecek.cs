﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOtomasyon1
{
    class İcecek
    {
       

        public string İcecekAd { get; set; }
        public int İcecekFiyat { get; set; }

      

        public override string ToString()
        {
            return string.Format("{0}--{1}", İcecekAd, İcecekFiyat);
        }
    }
}
